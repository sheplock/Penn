## Truth jet filter config for JZ4W
include("MC14JobOptions/JetFilter_JZ4.py")
include("MC14JobOptions/JetFilter_JZXW_Fragment.py")
