## Truth jet filter common config for all JZx and JZxW
include("MC14JobOptions/JetFilterAkt4.py")


