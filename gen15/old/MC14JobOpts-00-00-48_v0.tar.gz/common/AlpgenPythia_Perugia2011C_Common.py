## Common config for Alpgen+PYTHIA
include("MC14JobOptions/Pythia_Perugia2011C_Common.py")
include("MC14JobOptions/Pythia_Alpgen.py")

