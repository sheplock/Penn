## Truth jet filter config for JZ4
include("MC14JobOptions/JetFilter_JZX_Fragment.py")
filtSeq.QCDTruthJetFilter.MinPt = 500.*GeV
filtSeq.QCDTruthJetFilter.MaxPt = 1000.*GeV

