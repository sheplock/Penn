## Truth jet filter config for JZ0
include("MC14JobOptions/JetFilter_JZX_Fragment.py")
filtSeq.QCDTruthJetFilter.MinPt = 0.*GeV
filtSeq.QCDTruthJetFilter.MaxPt = 20.*GeV

