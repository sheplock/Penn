## Common config for Alpgen+HERWIG+JIMMY
evgenConfig.generators = ["Alpgen", "Herwig" , "Jimmy"]
genSeq.Herwig.HerwigCommand += ["iproc alpgen"]
