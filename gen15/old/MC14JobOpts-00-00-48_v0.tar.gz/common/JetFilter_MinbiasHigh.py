## Min bias truth jet filter for min bias sample preparation (high slice)

include("MC14JobOptions/AntiKt4TruthJets_pileup.py")
include("MC14JobOptions/AntiKt6TruthJets_pileup.py")

include("MC14JobOptions/JetFilter_Fragment.py")
filtSeq.QCDTruthJetFilter.MinPt = 35.*GeV
filtSeq.QCDTruthJetFilter.TruthJetContainer = "AntiKt6TruthJets"
filtSeq.QCDTruthJetFilter.DoShape = False
