## PHOTOS config for Jimmy

## Enable PHOTOS
include("MC14JobOptions/Photos_Fragment.py")
