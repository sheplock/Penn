## Truth jet filter config for JZ2
include("MC14JobOptions/JetFilter_JZX_Fragment.py")
filtSeq.QCDTruthJetFilter.MinPt = 80.*GeV
filtSeq.QCDTruthJetFilter.MaxPt = 200.*GeV

